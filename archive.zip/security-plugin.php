<?php
/*
Plugin Name: Custom Security Plugin
Description: Security plugin with URL exclusion, blocking, and comprehensive security features
Version: 1.2
Author: Your Name
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class CustomSecurityPlugin {
    private $excluded_paths = array();
    private $blocked_patterns = array();

    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('init', array($this, 'check_url_security'));
        add_action('plugins_loaded', array($this, 'block_direct_php_access'));
        add_action('send_headers', array($this, 'add_security_headers'));
        add_action('wp_footer', array($this, 'add_cookie_banner'));
        add_action('rest_api_init', array($this, 'register_cookie_consent_endpoint'));
        
        // Check and apply removal features
        $this->initialize_removal_features();
    }

    public function add_security_headers() {
    if (headers_sent()) {
        return;
    }

    // Only add headers if XSS protection is enabled
    if (get_option('security_enable_xss', true)) {
        // Modified CSP to allow AdSense, Gravatar and common third-party services
        header("Content-Security-Policy: ".
            "default-src 'self' *.google.com *.doubleclick.net; " .
            "script-src 'self' 'unsafe-inline' 'unsafe-eval' *.googleapis.com *.gstatic.com *.google.com *.doubleclick.net *.googleadservices.com *.google-analytics.com; " .
            "style-src 'self' 'unsafe-inline' *.googleapis.com; " .
            "img-src 'self' data: *.googleapis.com *.gstatic.com *.google.com *.doubleclick.net secure.gravatar.com; " .
            "font-src 'self' data: *.gstatic.com; " .
            "connect-src 'self' *.google.com *.doubleclick.net; " .
            "frame-src 'self' *.google.com *.doubleclick.net; " .
            "object-src 'none'; " .
            "upgrade-insecure-requests"
        );

        header('X-Frame-Options: SAMEORIGIN');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: same-origin');
        header('Permissions-Policy: accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()');
    }
    
    header_remove('Server');
}

    public function register_cookie_consent_endpoint() {
        register_rest_route('security-plugin/v1', '/cookie-consent', array(
            'methods' => 'POST',
            'callback' => array($this, 'handle_cookie_consent'),
            'permission_callback' => '__return_true'
        ));
    }

    public function handle_cookie_consent($request) {
        $consent = $request->get_param('consent');
        if ($consent) {
            setcookie('cookie_consent', 'accepted', time() + (365 * 24 * 60 * 60), '/', '', true, true);
        }
        return new WP_REST_Response(array('status' => 'success'), 200);
    }

    public function add_cookie_banner() {
        if (!isset($_COOKIE['cookie_consent'])) {
            ?>
            <style>
                .gdpr-banner {
                    position: fixed;
                    bottom: 0;
                    left: 0;
                    right: 0;
                    background: #f1f1f1;
                    padding: 20px;
                    text-align: center;
                    box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
                    z-index: 9999;
                }
                .gdpr-banner button {
                    margin: 0 10px;
                    padding: 8px 20px;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                }
                .gdpr-accept {
                    background: #4CAF50;
                    color: white;
                }
                .gdpr-reject {
                    background: #f44336;
                    color: white;
                }
            </style>
            <div class="gdpr-banner">
                <p>This website uses cookies to ensure you get the best experience. By continuing to use this site, you consent to our use of cookies.</p>
                <button class="gdpr-accept" onclick="acceptCookies()">Accept</button>
                <button class="gdpr-reject" onclick="rejectCookies()">Reject</button>
            </div>
            <script>
                function acceptCookies() {
                    fetch('/wp-json/security-plugin/v1/cookie-consent', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ consent: true })
                    }).then(() => {
                        document.querySelector('.gdpr-banner').style.display = 'none';
                    });
                }

                function rejectCookies() {
                    document.querySelector('.gdpr-banner').style.display = 'none';
                }
            </script>
            <?php
        }
    }

    public function sanitize_comment_content($content) {
        // Remove potentially harmful HTML tags and attributes
        $content = wp_kses($content, array(
            'a' => array('href' => array(), 'title' => array()),
            'b' => array(),
            'em' => array(),
            'strong' => array(),
            'p' => array()
        ));

        // Remove any null bytes
        $content = str_replace(chr(0), '', $content);

        return $content;
    }

    public function sanitize_post_content($content) {
        // Allow more tags for post content but still sanitize
        $allowed_html = wp_kses_allowed_html('post');
        $content = wp_kses($content, $allowed_html);
        
        // Remove any null bytes
        $content = str_replace(chr(0), '', $content);
        
        return $content;
    }

    public function sanitize_upload_filename($filename) {
        // Remove special characters from filename
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '', $filename);
        
        // Convert to lowercase
        $filename = strtolower($filename);
        
        return $filename;
    }

    public function sanitize_url($url, $original_url, $context) {
        // Remove any null bytes and encoded null bytes
        $url = str_replace(array("\0", "%00"), '', $url);
        
        // Remove any encoded JavaScript
        $url = preg_replace('/javascript:/i', '', $url);
        
        // Remove any data URIs
        $url = preg_replace('/data:/i', '', $url);
        
        return $url;
    }
  
  
  
  


    private function initialize_removal_features() {
        $remove_feeds = get_option('security_remove_feeds', false);
        $remove_oembed = get_option('security_remove_oembed', false);
        $remove_pingback = get_option('security_remove_pingback', false);
        $remove_wp_json = get_option('security_remove_wp_json', false);
        $remove_rsd = get_option('security_remove_rsd', false);
        $remove_wp_generator = get_option('security_remove_wp_generator', false);

        if ($remove_feeds) {
            remove_action('wp_head', 'feed_links', 2);
            remove_action('wp_head', 'feed_links_extra', 3);
        }

        if ($remove_oembed) {
            remove_action('wp_head', 'wp_oembed_add_discovery_links');
            remove_action('wp_head', 'wp_oembed_add_host_js');
        }

        if ($remove_pingback) {
            remove_action('wp_head', 'pingback_link');
            add_filter('xmlrpc_enabled', '__return_false');
        }

        if ($remove_wp_json) {
            // Remove WP REST API links
            remove_action('wp_head', 'rest_output_link_wp_head');
            remove_action('template_redirect', 'rest_output_link_header', 11);
        }

        if ($remove_rsd) {
            // Remove RSD link
            remove_action('wp_head', 'rsd_link');
        }

        if ($remove_wp_generator) {
            // Remove WordPress version
            remove_action('wp_head', 'wp_generator');
        }
    }

     public function block_direct_php_access() {
        // Exit early if in admin
        if (is_admin()) {
            return;
        }

        // Get the requested path
        $request_uri = $_SERVER['REQUEST_URI'];
        
        // Check if it's a PHP file request
        if (preg_match('/\.php$/i', $request_uri)) {
            $current_path = trim($request_uri, '/');
            $excluded_php_paths = explode("\n", get_option('security_excluded_php_paths', ''));
            
            // Check if path is excluded
            foreach ($excluded_php_paths as $excluded_path) {
                $excluded_path = trim($excluded_path, '/');
                if (!empty($excluded_path) && strpos($current_path, $excluded_path) === 0) {
                    return;
                }
            }
            
            // Block access with 403
            status_header(403);
            nocache_headers();
            header('HTTP/1.1 403 Forbidden');
            header('Status: 403 Forbidden');
            if (!headers_sent()) {
                header('Content-Type: text/html; charset=utf-8');
            }
            die('403 Forbidden');
        }
    }

    public function add_admin_menu() {
        add_menu_page(
            'Security Settings',
            'Security Settings',
            'manage_options',
            'security-settings',
            array($this, 'settings_page'),
            'dashicons-shield'
        );
    }

        public function settings_page() {
        if (isset($_POST['save_settings'])) {
            $this->save_settings();
        }

        $excluded_paths = get_option('security_excluded_paths', '');
        $blocked_patterns = get_option('security_blocked_patterns', '');
        $excluded_php_paths = get_option('security_excluded_php_paths', '');
        $remove_feeds = get_option('security_remove_feeds', false);
        $remove_oembed = get_option('security_remove_oembed', false);
        $remove_pingback = get_option('security_remove_pingback', false);
        $remove_wp_json = get_option('security_remove_wp_json', false);
        $remove_rsd = get_option('security_remove_rsd', false);
        $remove_wp_generator = get_option('security_remove_wp_generator', false);
        $cookie_notice_text = get_option('security_cookie_notice_text', 'This website uses cookies to ensure you get the best experience. By continuing to use this site, you consent to our use of cookies.');
        ?>

        <div class="wrap">
            <h1>Security Settings</h1>
            <form method="post">
              
              
     <?php wp_nonce_field('security_settings_nonce', 'security_nonce'); ?>
                <!-- Previous form fields remain the same... -->
                <table class="form-table">
                    <tr>
                        <th>XSS Protection</th>
                        <td>
                            <p class="description">XSS protection is enabled by default and includes:</p>
                            <ul style="list-style-type: disc; margin-left: 20px;">
                                <li>Content Security Policy (CSP) headers</li>
                                <li>Input sanitization for comments and posts</li>
                                <li>Secure file upload handling</li>
                                <li>URL parameter sanitization</li>
                            </ul>
                        </td>
                    </tr>
                  
                   <th>Security Features</th>
        <td>
            <label>
                <input type="checkbox" name="enable_xss" value="1" <?php checked(get_option('security_enable_xss', true)); ?>>
                Enable XSS Protection
            </label>
            <p class="description">Controls Content Security Policy and other XSS protection features</p>
        </td>
  

                
   <th>Cookie Notice Text</th>
                        <td>
                            <textarea name="cookie_notice_text" rows="3" cols="50"><?php echo esc_textarea($cookie_notice_text); ?></textarea>
                            <p class="description">Customize the cookie consent notice text</p>
                        </td>
                    </tr>
                  
                  
                  
                    <tr>
                        <th>Excluded Paths</th>
                        <td>
                            <textarea name="excluded_paths" rows="5" cols="50"><?php echo esc_textarea($excluded_paths); ?></textarea>
                            <p class="description">Enter one path per line (e.g., wp-admin, wp-login.php)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>PHP Access Exclusions</th>
                        <td>
                            <textarea name="excluded_php_paths" rows="5" cols="50"><?php echo esc_textarea($excluded_php_paths); ?></textarea>
                            <p class="description">Enter paths to allow PHP access (e.g., wp-admin, wp-login.php)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Blocked Patterns</th>
                        <td>
                            <textarea name="blocked_patterns" rows="5" cols="50"><?php echo esc_textarea($blocked_patterns); ?></textarea>
                            <p class="description">Enter one pattern per line (e.g., %3C, %3E)</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Remove Features</th>
                        <td>
                            <label>
                                <input type="checkbox" name="remove_feeds" value="1" <?php checked($remove_feeds); ?>>
                                Remove RSS Feeds
                            </label><br>
                            <label>
                                <input type="checkbox" name="remove_oembed" value="1" <?php checked($remove_oembed); ?>>
                                Remove oEmbed Links
                            </label><br>
                            <label>
                                <input type="checkbox" name="remove_pingback" value="1" <?php checked($remove_pingback); ?>>
                                Remove Pingback and Disable XMLRPC
                            </label><br>
                            <label>
                                <input type="checkbox" name="remove_wp_json" value="1" <?php checked($remove_wp_json); ?>>
                                Remove WP REST API Links (wp-json)
                            </label><br>
                            <label>
                                <input type="checkbox" name="remove_rsd" value="1" <?php checked($remove_rsd); ?>>
                                Remove RSD Link
                            </label><br>
                            <label>
                                <input type="checkbox" name="remove_wp_generator" value="1" <?php checked($remove_wp_generator); ?>>
                                Remove WordPress Generator Meta Tag
                            </label>
                        </td>
                    </tr>
                </table>
                <p>
                    <input type="submit" name="save_settings" class="button button-primary" value="Save Settings">
                </p>
            </form>
        </div>
        <?php
    }

     // Update your save_settings() method
private function save_settings() {
    if (!current_user_can('manage_options')) {
        return;
    }

        // Verify nonce
    if (!isset($_POST['security_nonce']) || !wp_verify_nonce($_POST['security_nonce'], 'security_settings_nonce')) {
        wp_die('Security check failed');
    }

    // Add XSS protection toggle
     update_option('security_enable_xss', isset($_POST['enable_xss']));

        $excluded_paths = isset($_POST['excluded_paths']) ? sanitize_textarea_field($_POST['excluded_paths']) : '';
        $blocked_patterns = isset($_POST['blocked_patterns']) ? sanitize_textarea_field($_POST['blocked_patterns']) : '';
        $excluded_php_paths = isset($_POST['excluded_php_paths']) ? sanitize_textarea_field($_POST['excluded_php_paths']) : '';
        
        // Save removal settings
        update_option('security_remove_feeds', isset($_POST['remove_feeds']));
        update_option('security_remove_oembed', isset($_POST['remove_oembed']));
        update_option('security_remove_pingback', isset($_POST['remove_pingback']));
        update_option('security_remove_wp_json', isset($_POST['remove_wp_json']));
        update_option('security_remove_rsd', isset($_POST['remove_rsd']));
        update_option('security_remove_wp_generator', isset($_POST['remove_wp_generator']));
        
        update_option('security_excluded_paths', $excluded_paths);
        update_option('security_blocked_patterns', $blocked_patterns);
        update_option('security_excluded_php_paths', $excluded_php_paths);
    }

    public function check_url_security() {
        if (is_admin()) {
            return;
        }

        $current_url = $_SERVER['REQUEST_URI'];
        
        // Check excluded paths
        $excluded_paths = explode("\n", get_option('security_excluded_paths', ''));
        foreach ($excluded_paths as $path) {
            $path = trim($path);
            if (!empty($path) && strpos($current_url, $path) !== false) {
                return;
            }
        }

        // Check blocked patterns
        $blocked_patterns = explode("\n", get_option('security_blocked_patterns', ''));
        foreach ($blocked_patterns as $pattern) {
            $pattern = trim($pattern);
            if (!empty($pattern) && strpos($current_url, $pattern) !== false) {
                wp_die('Access denied', 'Security Error', array('response' => 403));
            }
        }

        // Remove query strings
        if (!empty($_SERVER['QUERY_STRING'])) {
            wp_redirect(home_url(remove_query_arg(array_keys($_GET))), 301);
            exit;
        }
    }
}

// Initialize the plugin
$custom_security_plugin = new CustomSecurityPlugin();